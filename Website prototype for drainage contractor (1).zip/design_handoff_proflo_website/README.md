# Handoff: PRO FLO Drainage & Landscape Construction website

## Overview
This is a redesigned marketing site for PRO FLO Drainage & Landscape Construction (proflodrainage.com). PRO FLO is a family-owned drainage and landscape construction company based in Surrey, BC, with 30+ years of industry experience. It serves the Lower Mainland and Fraser Valley.

**The goal is calls, texts and free-estimate requests.** The phone number 604-369-0039 must be visible on every screen and tappable as `tel:+16043690039`. Texting is a first-class contact method (`sms:+16043690039`).

This package covers the **Home page**. The current site also has a Photo Gallery page and a Contact page. Build those in the same system (spec at the bottom).

## About the design files
`Home.dc.html` is a **design reference built in HTML**. It is a prototype showing the intended look and behavior, not production code to copy. To view it, open it in a browser with `support.js` alongside.

Recreate the design in the target stack. If no codebase exists yet, use Astro or Next.js with static output, plus plain CSS or Tailwind. Host on Netlify, Vercel or Cloudflare Pages. The site is content-heavy with minimal JS, and SEO matters.

How the file is organized:
- The markup is the template.
- The `class Component` script at the bottom holds all data arrays (steps, services, before/after items, process, reviews) and the interaction state.
- Styles are inline. Extract them into CSS or components.

## Fidelity
**High fidelity.** Colors, typography, spacing, copy and interactions are final.

## Design tokens

### Colors
| Token | Hex | Use |
|---|---|---|
| navy | `#0B1E2D` | Header, hero, service area, footer backgrounds; primary text on light; dark buttons; rules |
| paper | `#F6F6F2` | Page background; text on navy |
| flo-blue | `#4C96D7` | Brand blue (from their logo / theme-color). Services section background, primary button on navy, selected chips, success panel |
| flo-blue-light | `#7DB6E8` | Phone number and accents on navy, footer link hover |
| link-blue | `#1C64A8` | Links and big phone number on light backgrounds; dark button hover |
| mist | `#E6ECEF` | About section background |
| img-bg | `#DCE5EC` | Image loading placeholder |
| on-navy | `#CFDCE6` | Body text on navy |
| on-navy-muted | `#A9C4DB` | Meta text on navy |
| footer-muted | `#8FA6B8` | Copyright line |
| body-2 | `#3A4A56` / `#2C3B47` | Secondary body text on paper / mist |
| meta | `#4A5B68` | Captions, helper text |

### Typography
- One family: **Archivo** (Google Fonts, variable). Use both axes: `wdth 62..125` and `wght 400..900`.
- Body: 18px, line-height 1.5, weight 400, `font-stretch: 100%`.
- **Headlines:**
  - Weight 800, **`font-stretch: 125%`** (expanded width).
  - Letter-spacing -.035em, line-height .95–.98, sentence case.
  - This expanded headline style is the signature of the brand. Keep it.
- **Size scale:**
  - H1: `clamp(44px, 6.2vw, 104px)`, `text-wrap: balance`. The second sentence is in flo-blue.
  - H2: `clamp(38px, 4.6vw, 76px)`. The quote section H2 is `clamp(40px, 5vw, 84px)`.
  - Sub-headings (step names, process titles, text-box title): weight 800, `font-stretch: 115%`, 22–28px, ls -.02em.
  - Phone number:
    - Header: 800 weight, stretch 115%, 25px.
    - Quote section: stretch 120%, `clamp(40px, 4.6vw, 72px)`.
  - Logo wordmark "PRO FLO": 800 weight, stretch 125%, 19px.
- The minimum text size is 14px, used only for the header sub-label and the copyright line.

### Shape
- Buttons and inputs: **6px** radius.
- Photos: **10px** radius.
- Hero text-box card: **14px**.
- Success panel: 12px.
- Tab track: 9px.
- Rules are `1.5px solid #0B1E2D`.
- No shadows, no gradients, no icon rows, no numbered labels.

### Layout
- Max content width 1480px. Side padding `clamp(16px, 3vw, 40px)`.
- Section vertical padding `clamp(56px, 7vw, 110px)`.
- Two-column sections use `grid-template-columns: repeat(auto-fit, minmax(min(100%, 460–540px), 1fr))` with a column gap of `clamp(32px, 5vw, 88px)`. They stack naturally below that width.
- **Breakpoint: 1100px.** Below it:
  - Hide the desktop nav and header button. The header shows only the logo and the tappable phone number.
  - Show the sticky bottom bar.

## Home page sections

1. **Header**
   - Sticky, 80px tall, navy.
   - Left:
     - Logo image, 56×56, `object-fit: contain`.
     - Next to it, "PRO FLO" over "Drainage & Landscape" (14px, on-navy-muted).
   - Nav, 17px / 500, gap 26px, links turn flo-blue-light on hover:
     - Drainage
     - Landscape construction
     - Before & after
     - About
     - Contact
   - "Call or text" (14px) stacked over **604-369-0039** (flo-blue-light, `white-space: nowrap`).
   - **"Free estimate"** button:
     - Flo-blue background, navy text, 700 weight, padding 14px 20px.
     - Hover: paper background.

2. **Hero** (navy)
   - Two columns, vertically centered.
   - **Left column:**
     - Eyebrow (17px, on-navy-muted): "Family owned · 30+ years · Lower Mainland & Fraser Valley"
     - H1: "Water goes away from your house. **We make sure of it.**" The second sentence is in flo-blue.
     - Sub (20px, on-navy): "Perimeter and yard drainage, sewer and water lines, sumps, foundation cracks. Then the walls, patios and walkways that go back on top."
     - Buttons:
       - **Call 604-369-0039**: flo-blue background, padding 17px 24px.
       - **Book a free site visit**: 1.5px paper outline. Hover inverts.
   - **Right column: "Text us the problem" card**
     - Paper background, 14px radius, max-width 600, right-aligned in the column.
     - Title row: "Text us the problem" with "Photos welcome" on the right.
     - Six toggle chips:
       - Water in basement
       - Soggy yard
       - Sewer backing up
       - Retaining wall
       - Patio or walkway
       - Foundation crack
     - Chip styling:
       - Off: 1.5px navy border, transparent.
       - On: flo-blue background and border.
       - Min height 44px.
     - **Toggling chips rewrites the message:** "Hi PRO FLO, I need a quote for: {chips joined, lowercase}. Address: ".
     - Below the chips, an editable textarea: white, 1.5px navy border, 10px radius, 4 rows. Placeholder: "Hi, water is pooling against the back of the house after rain. Can you come take a look? I'm in Surrey."
     - **"Send as a text"** button:
       - Navy, full-flex.
       - Links to `sms:+16043690039?&body={encodeURIComponent(message)}`. Use `sms:…?&body=` for iOS and Android compatibility.
       - Helper text next to it: "Opens your messages app to 604-369-0039. We usually reply the same day."
   - **Photo strip** below the columns:
     - Grid `2fr 1fr 1fr`, gap 12px.
     - Height `clamp(200px, 26vw, 420px)`, cover, 10px radius.
     - Photos: patio and block steps, a trench along a wall with an excavator, a timber wall.

3. **Proof strip**
   - Paper background, 1.5px navy bottom border.
   - Grid `repeat(auto-fit, minmax(140px, 1fr))`. Items:
     - HomeStars Verified badge (64px tall)
     - BBB A+ Rating badge (48px tall)
     - "30+ years in the trade"
     - "Free site visit + written quote"
     - "All major credit cards"
   - Text items are 18px / 700.

4. **Drainage: "Find it first. Then fix only what's broken."**
   - **Left column:**
     - H2, then the intro: "Most drainage calls start with "the basement smells" or "the yard won't dry out." We don't guess and we don't dig the whole house to find out. Here's the order we work in:"
     - A 3-row **selectable list**. Each row is full width with a 1.5px navy bottom border, min height 64px, padding 20px 18px.
       - Title on the left: 800 weight, stretch 115%, `nowrap`.
       - Tag on the right: 16px / 500, `nowrap`.
     - The active row has a navy background and paper text.
     - The paragraph under the list shows the active step's body.
   - **Right column:** the active step's 4:3 photo, with its caption below in 15px meta.
   - Steps:
     - **Video inspection** (tag "See it"): "We push a camera through your perimeter and sewer lines and watch it on screen with you. Roots, crushed pipe, sags and silt all show up, along with exactly where they are."
     - **Hydro flushing** (tag "Try the easy fix"): "If the pipe is sound but full of silt, a high-pressure flush cleans it out. Sometimes that's all a house needs, and it costs a fraction of a dig."
     - **Repair or replace** (tag "Dig only what's broken"): "Spot repair, one side, or the full perimeter, plus sump, damp proofing and membrane where it's needed. Then we put your yard back."

5. **Services: "Everything from the drain tile up."** (flo-blue background, navy text)
   - **Segmented tabs** in a navy track (5px padding, 9px radius):
     - Active tab: paper background, navy text.
     - Inactive tabs: transparent background, paper text.
     - All tabs: `nowrap`, min height 44px.
   - Below the tabs:
     - Left: the active service's photo (5:4).
     - Right:
       - An intro line, 21px / 500.
       - The item list. Each row has the name on the left (19px / 600, nowrap) and an optional note on the right (16px / 400, nowrap), with 1.5px navy rules.
   - **Drainage**
     - Intro: "Wet basement, soggy yard, a sewer line that keeps backing up. We find the cause and fix it properly."
     - Items:
       - Perimeter & yard drainage (Repair or full replacement)
       - Water & sewer mains (Repairs and replacement)
       - Sump installations
       - Hydro flushing (Perimeter drain cleaning)
       - Video inspections (Drain and sewer pipe)
       - Foundation crack repairs
       - Damp proofing & membrane (Foundation walls)
   - **Landscape construction**
     - Intro: "The hard stuff that has to last: walls that hold, concrete that drains, stairs that don't heave."
     - Items:
       - Retaining walls (Block and timber)
       - Sidewalks (Concrete and pavers)
       - Patios
       - Stairs
       - Wood decks & fencing
       - Mini excavator work (Tight side yards)
   - **General landscaping**
     - Intro: "Finishing the yard once the heavy work is done, or a cleanup on its own."
     - Items:
       - Tree & shrub planting
       - Mulch or rock beds
       - Seed or sod lawns
       - Landscape edging
       - Excavation & grading (Slope it away from the house)

6. **Before & after**
   - H2 with a right-side note: "Real jobs from this year and last. Tap any photo to see it bigger."
   - Grid `repeat(auto-fill, minmax(min(100%, 300px), 1fr))`, gap 16px.
   - Each item: a 3:4 cover photo (10px radius), then a caption with a bold title followed by a sentence. Their photos are already composite before/after images.
   - **Click opens a lightbox:**
     - Fixed overlay `rgba(11,30,45,.94)`.
     - Image at max-height 82vh with its caption.
     - Clicking anywhere closes it. Add Esc-to-close and focus trapping in production.
   - Items:
     - Retaining wall. Rotting timber wall replaced with a block wall.
     - Front stairs. Old wood steps out, poured concrete stairs in.
     - Walkway. Mud path turned into a concrete walk to the door.
     - Backyard wall. Fence-line slope held back with block.
     - Side yard. New sidewalk wrapping around the house.
     - Retaining wall. Second tier, same job.
     - Backyard wall. Finished wall with level lawn above.
     - Concrete wall. Poured retaining wall with drain rock behind.

7. **About** (mist background)
   - H2: "A family business. The same people from quote to cleanup."
   - Two paragraphs:
     - "PRO FLO is family owned and run out of Surrey, with more than 30 years in drainage and landscape construction between us."
     - "We come out, look at the site with you, and give you a written quote you can actually read. If it's a drainage fix and a patio, it's one crew and one bill."
   - Right column: a four-row process list, each row a title and a description:
     - You call or text: "Send a photo if you can. We reply the same day."
     - Free site visit: "We walk it with you and tell you what we'd do and why."
     - Written quote: "Line by line, so you can compare it fairly."
     - Work and cleanup: "Same crew start to finish. Yard put back before we leave."

8. **Reviews**
   - Two large quotes side by side: `clamp(24px, 2.4vw, 34px)`, weight 500.
   - Each quote has an attribution line: bold name, then "· job type" in meta.
   - Footer line: "More reviews on HomeStars and Facebook".
   - **The two review texts are placeholders written for the mockup. Replace them with real HomeStars reviews before launch.**

9. **Service area** (navy)
   - Intro: "Based in Surrey. We work from Vancouver to Abbotsford:"
   - One large sentence: "Vancouver, Burnaby, New Westminster, Richmond, Delta, Surrey, White Rock, Langley, Coquitlam, Port Moody, Pitt Meadows, Maple Ridge and Abbotsford." The word "and" is in flo-blue-light.

10. **Quote**
    - H2: "Free site visit. Written quote. No pressure."
    - Big phone number in link-blue, then "Call or text. proflodrainage@gmail.com".
    - Form fields:
      - Name (required)
      - Phone (required)
      - Address of the job
      - What's going on? (textarea; placeholder "Water in the crawlspace every winter. House built 1985.")
    - Inputs: 54px tall, 1.5px navy border, 6px radius, white background.
    - Submit button: "Request my free site visit".
    - **On success**, replace the form with a flo-blue panel: "Thanks, we've got it." / "We'll call you back to set up a time to come out, usually the same day."
    - Wire the form to a real handler (Formspree, Netlify Forms, or an API route that emails proflodrainage@gmail.com). Add spam protection: the current site uses reCAPTCHA; a honeypot or Turnstile also works.

11. **Footer** (navy), four columns:
    - Logo and name.
    - Phone, email, and address (Unit 441, 7184 120th St, Surrey, BC V3W 0M6).
    - Section links.
    - Facebook (facebook.com/proflodrainage), Instagram (instagram.com/proflodrainage), and "All major credit cards accepted".
    - Links have no underline and turn flo-blue-light on hover.

12. **Mobile sticky bar** (below 1100px)
    - Fixed to the bottom, two halves, 60px tall:
      - **Call** (flo-blue, `tel:`)
      - **Text a photo** (navy, `sms:`)
    - Add 60px of bottom padding to the page so the bar doesn't cover content.

## State
- `selectedChips: string[]` and `message: string`. Chip toggles regenerate the message; the textarea stays editable.
- `activeStep: 0..2`, default 0.
- `activeService: 0..2`, default 0.
- `lightboxIndex: number | null`.
- `formSent: boolean`.
- Viewport breakpoint at 1100px. Use a CSS media query in production, not JS.
- No animations are required. If you add any, keep them subtle, around 150–200ms on hover color changes.

## Pages still to build (same system)
- **Gallery** (`/photo-gallery`)
  - Category tabs, styled like the services tabs: Concrete & Retaining Walls, Drainage, Decks, General Landscaping.
  - The same grid and lightbox as the home Before & after section.
  - The current site has around 20+ images in Concrete & Retaining Walls. The drainage, deck and landscaping images need to be pulled from their GoDaddy media library or supplied by the client.
- **Contact** (`/contact-us`)
  - The quote section from the home page, expanded, with a "Text us the problem" card beside the form.
  - Address, hours (get these from the client), and the line "We would be happy to do an on-site visit and discuss your project needs at your convenience."
  - No map embed.

## Copy rules
Short, plain and specific. Say what they fix and where. Avoid "client focused", "dedicated to providing", "top service", "quality workmanship" and other generic contractor filler (the current site uses these). Speak as "we", the family crew.

## Assets
All images come from the client's current GoDaddy site:
- Base URL: `https://img1.wsimg.com/isteam/ip/84a84f38-0a31-41e9-afff-9ceec56e0e81/`
- Resize suffix: `/:/rs=w:{width},cg:true,m`

**Download the originals and self-host them** as WebP or AVIF with responsive `srcset`. Files used:
- Logo: `logo-nobackground-500.png` (circular badge mark). Get a vector version from the client if possible.
- Badges: `Homestars%20Badge.png`, `bbb_a_rating_logo.jpg`.
- Hero strip: `IMG_1251.JPG` (patio and steps), `IMG_0688.JPG` (trench along a wall with an excavator), `IMG_1971.JPG` (timber wall).
- Drainage steps: `IMG_0688.JPG`, `IMG_1977.JPG`, `IMG_1973.JPG`.
- Services tabs: `IMG_1977.JPG` (drainage), `IMG_1246.JPG` (landscape construction), `IMG_1259%20%282%29.JPG` (general landscaping).
- Before & after:
  - `Val%20Wall%20Before-After%201.jpg`, `Val%20Wall%20Before-After%202.jpg`
  - `Stairs%20Before%20%26%20After1.jpg`
  - `Walkway%20Before%20%26%20After1.jpg`
  - `Morgan%20Wall%20Before-After%201.jpg`, `Morgan%20Wall%20Before-After%202.jpg`
  - `Sidewalk%20Before%20%26%20After1.jpg`
  - `Retaining%20Wall.jpg`

**Still needed from the client:**
- Real drainage job photos: open trenches, new perimeter pipe, camera screen shots.
- A team or family photo for the About section.
- Real review text.
- Business hours.

## Files
- `Home.dc.html`: the Home page design reference. Open it in a browser next to `support.js`.
- `support.js`: the runtime needed to open the reference file. It is not for production.

## Before launch
- Confirm the claims with the client: "We usually reply the same day", and the service area list (taken from their current site).
- Set up local SEO:
  - A `LocalBusiness` schema with the address and phone.
  - A page title along the lines of "Drainage Contractor Surrey & Lower Mainland | PRO FLO Drainage".
  - Meta descriptions.
  - Image alt text (already written in the reference).
